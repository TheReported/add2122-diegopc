#!/usr/bin/env bash

option=c
if  [ "${option}" = "c" ] ;then
	echo "Ejecutando el script crear-usuarios23.sh"
	cd /home/diego/scripts23/secuencial23/ && bash crear-usuarios23.sh
	elif [ "${option}" = 'b' ]; then
		echo "Ejecutando el script borrar-usuarios23.sh"
		cd /home/diego/scripts23/secuencial23/ && bash borrar-usuarios23.sh
	else
		echo "ERROR!! Debes elegir alguna de las opciones válidas. "
		sl
		exit 1
	fi
