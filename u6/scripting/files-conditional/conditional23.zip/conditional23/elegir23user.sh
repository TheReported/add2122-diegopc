#!/usr/bin/env bash

echo "

- Elige la opción 'c' para crear 10 usuarios <diegob>
- Elige la opción 'b' para borrar 10 usuarios <diegob>

"

read -p "Escriba la opción que desee: " option

if  [ "${option}" = "c" ] ;then
	echo "Ejecutando el script crear-usuarios23.sh"
	cd /home/diego/scripts23/secuencial23/ && bash crear-usuarios23.sh
	elif [ "${option}" = 'b' ]; then
		echo "Ejecutando el script borrar-usuarios23.sh"
		cd /home/diego/scripts23/secuencial23/ && bash borrar-usuarios23.sh
	else
		echo "ERROR!! Debes elegir alguna de las opciones válidas. "
		sl
		exit 1
	fi
