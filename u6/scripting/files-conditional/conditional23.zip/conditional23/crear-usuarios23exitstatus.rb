#!/bin/ruby
puts "\e[0;36mCreando 10 usuarios <diegor>\e[m"
       if system ("grep diego1r /etc/passwd"); then
                puts "El usuario diego1r ya existe"
        else
                puts "Creando el usuario diego1r"
		system ("sudo useradd -m diego1r -s /bin/bash -p $(mkpasswd --method=sha-512 'diego1r')")
        	
	end
	
	if system ("grep diego2r /etc/passwd"); then
                puts "El usuario diego2r ya existe"
        else
		puts "Creando el usuario diego2r"
 	       	system ("sudo useradd -m diego2r -s /bin/bash -p $(mkpasswd --method=sha-512 'diego2r')")
	end
        
	if system ("grep diego3r /etc/passwd"); then
                puts "El usuario diego3r ya existe"
        else
		puts"Creando el usuario diego3r"
		system ("sudo useradd -m diego3r -s /bin/bash -p $(mkpasswd --method=sha-512 'diego3r')")
	end
        
	if system ("grep diego4r /etc/passwd"); then
                puts"El usuario diego4r ya existe"
        else
		puts "Creando el usuario diego4r"
		system ("sudo useradd -m diego4r -s /bin/bash -p $(mkpasswd --method=sha-512 'diego4r')")
	end
        
	if system ("grep diego5r /etc/passwd"); then
                puts "El usuario diego5r ya existe"
        else
		puts "Creando el usuario diego5r"
		system ("sudo useradd -m diego5r -s /bin/bash -p $(mkpasswd --method=sha-512 'diego5r')")
	end
        
	if system ("grep diego6r /etc/passwd"); then
                puts "El usuario diego6r ya existe"
        else
		puts "Creando el usuario diego6r"
		system ("sudo useradd -m diego6r -s /bin/bash -p $(mkpasswd --method=sha-512 'diego6r')")
	end
        
	if system ("grep diego7r /etc/passwd"); then
                puts "El usuario diego7r ya existe"
        else
		puts "Creando el usuario diego7r"	
		system ("sudo useradd -m diego7r -s /bin/bash -p $(mkpasswd --method=sha-512 'diego7r')")
	end
       
	if system ("grep diego8r /etc/passwd"); then
                puts "El usuario diego8r ya existe"
        else
		puts "Creando el usuario diego8r"
		system ("sudo useradd -m diego8r -s /bin/bash -p $(mkpasswd --method=sha-512 'diego8r')")
	end
	
	if system ("grep diego9r /etc/passwd"); then
                puts "El usuario diego9r ya existe"
        else
		puts "Creando el usuario diego9r"
        	system ("sudo useradd -m diego9r -s /bin/bash -p $(mkpasswd --method=sha-512 'diego9r')")
	end

	if system ("grep diego10r /etc/passwd"); then
                puts "El usuario diego10r ya existe"
        else	
		puts "Creando el usuario diego10r"
		system ("sudo useradd -m diego10r -s /bin/bash -p $(mkpasswd --method=sha-512 'diego10r')")
	end
puts "\e[1;35mComprobamos que se han creado los usuarios correctamente\e[m"
system ("id diego1r")
system ("id diego2r")
system ("id diego3r")
system ("id diego4r")
system ("id diego5r")
system ("id diego6r")
system ("id diego7r")
system ("id diego8r")
system ("id diego9r")
system ("id diego10r")
puts "\e[0;33mUsuarios creados correctamente\e[m"
