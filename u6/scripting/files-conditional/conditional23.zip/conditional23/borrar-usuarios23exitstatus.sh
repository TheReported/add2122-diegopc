#!/bin/bash
echo -e "\e[0;36mEliminando 10 usuarios <diegob>\e[0m"
       if grep diego1b /etc/passwd; then
                echo "Borrando el usuario diego1b"
        	sudo userdel -r diego1b > /dev/null 2>&1
        else
                echo "El usuario diego1b no existe"
        	
	fi 
	
	if grep diego2b /etc/passwd; then
                echo "Borrando el usuario diego2b"
        	sudo userdel -r diego2b > /dev/null 2>&1
        else
		echo "El usuario diego2b no existe"
	fi
        
	if grep diego3b /etc/passwd; then
                echo "Borrando el usuario diego3b"
        	sudo userdel -r diego3b > /dev/null 2>&1
        else
		echo "El usuario diego3b no existe"
	fi
        
	if grep diego4b /etc/passwd; then
                echo "Borrando el usuario diego4b"
        	sudo userdel -r diego4b > /dev/null 2>&1
        else
		echo "El usuario diego4b no existe"
	fi
        
	if grep diego5b /etc/passwd; then
                echo "Borrando el usuario diego5b"
        	sudo userdel -r diego5b > /dev/null 2>&1
        else
		echo "El usuario diego5b no existe"
	fi
        
	if grep diego6b /etc/passwd; then
                echo "Borrando el usuario diego6b"
        	sudo userdel -r diego6b > /dev/null 2>&1
        else
		echo "El usuario diego6b no existe"
	fi
        
	if grep diego7b /etc/passwd; then
                echo "Borrando el usuario diego7b"
        	sudo userdel -r diego7b > /dev/null 2>&1
        else
		echo "El usuario diego7b no existe"
	fi
       
	if grep diego8b /etc/passwd; then
                echo "Borrando el usuario diego8b"
        	sudo userdel -r diego8b > /dev/null 2>&1
        else
		echo "El usuario diego8b no existe"
	fi
	
	if grep diego9b /etc/passwd; then
		echo "Borrando el usuario diego9b"
        	sudo userdel -r diego9b > /dev/null 2>&1
        else
		echo "El usuario diego9b no existe"
	fi

	if grep diego10b /etc/passwd; then
                echo "Borrando el usuario diego10b"
        	sudo userdel -r diego10b > /dev/null 2>&1
        else	
		echo "El usuario diego10b no existe"
	fi


echo -e "\e[1;35mComprobamos que se han eliminado los usuarios correctamente\e[0m"
cat /etc/passwd | grep diego --color=auto
cowsay "¡Usuarios borrados!"
