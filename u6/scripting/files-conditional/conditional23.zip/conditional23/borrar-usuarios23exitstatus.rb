#!/usr/bin/env ruby
puts "\e[0;36mEliminando 10 usuarios <diegor>\e[m"

       if system ("grep diego1r /etc/passwd"); then
                puts "Borrando el usuario diego1r"
		system ("sudo userdel -r diego1r > /dev/null 2>&1 ")
        else
                puts "El usuario diego1r no existe"
        	
	end
	
	if system ("grep diego2r /etc/passwd"); then
		puts "Borrando el usuario diego2r"
                system ("sudo userdel -r diego2r > /dev/null 2>&1 ")
        else
		puts "El usuario diego2r no existe"
	end
        
	if system ("grep diego3r /etc/passwd"); then
		puts "Borrando el usuario diego3r"
        	system ("sudo userdel -r diego3r > /dev/null 2>&1 ")
	else
		puts "El usuario diego3r no existe"
	end
        
	if system ("grep diego4r /etc/passwd"); then
		puts "Borrando el usuario diego4r"
                system ("sudo userdel -r diego4r > /dev/null 2>&1 ")
        else
		puts "El usuario diego4r no existe"
	end
        
	if system ("grep diego5r /etc/passwd"); then
		puts "Borrando el usuario diego5r"
                system ("sudo userdel -r diego5r > /dev/null 2>&1 ")
        else
		puts "El usuario diego5r no existe"
	end
        
	if system ("grep diego6r /etc/passwd"); then
		puts "Borrando el usuario diego6r"
                system ("sudo userdel -r diego6r > /dev/null 2>&1 ")
        else
		puts "El usuario diego6r no existe"
	end
        
	if system ("grep diego7r /etc/passwd"); then
		puts "Borrando el usuario diego7r"
                system ("sudo userdel -r diego7r > /dev/null 2>&1 ")
        else
		puts "El usuario diego7r no existe"
	end
       
	if system ("grep diego8r /etc/passwd"); then
		puts "Borrando el usuario diego8r"
                system ("sudo userdel -r diego8r > /dev/null 2>&1 ")
        else
		puts "El usuario diego8r no existe"
	end
	
	if system ("grep diego9r /etc/passwd"); then
		puts "Borrando el usuario diego9r"
                system ("sudo userdel -r diego9r > /dev/null 2>&1 ")
        else
		puts "El usuario diego9r no existe"
	end

	if system ("grep diego10r /etc/passwd"); then
		puts "Borrando el usuario diego10r"
                system ("sudo userdel -r diego10r > /dev/null 2>&1 ")
        else	
		puts "El usuario diego10r no existe"
	end
puts "\e[1;35mComprobamos que se han eliminado los usuarios correctamente\e[m"
system ("cat /etc/passwd | grep diego --color=auto")
system ("xcowsay ¡Usuarios borrados!")
