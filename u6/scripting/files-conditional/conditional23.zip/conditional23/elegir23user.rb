#!/usr/bin/env ruby

puts "

- Elige la opción 'c' para crear 10 usuarios <diegor>
- Elige la opción 'b' para borrar 10 usuarios <diegor>

"
print "Elige la opción que quieres escoger: "
option = gets.chomp

if   (option == "c")
	puts "Ejecutando el script crear-usuarios23.rb"
	system ("cd /home/diego/scripts23/secuencial23/ && ruby crear-usuarios23.rb")
	elsif (option == "b")
		puts "Ejecutando el script borrar-usuarios23.rb"
		system ("cd /home/diego/scripts23/secuencial23/ && ruby borrar-usuarios23.rb")
	else
		puts "ERROR!! Debes elegir alguna de las opciones válidas. "
		system ("sl")
		exit 1
	end
